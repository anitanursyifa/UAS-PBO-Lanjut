/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KonserinApp;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author felia
 */  
public class koneksi {
    Connection con;
    Statement stm;
    public koneksi(){
        String id, pass, driver, url;
       
        try {
            url ="jdbc:mysql://localhost/konserin_db";
            id="root";
            pass="";
            Class.forName("com.mysql.jdbc.Driver");
            con =DriverManager.getConnection(url,id,pass);
            stm = con.createStatement();
            System.out.println("koneksi berhasil;");
        } catch (Exception e) {
            System.err.println("koneksi gagal" +e.getMessage());
        }
    }
    public static void main(String []args){
    koneksi k = new koneksi();
    }
}
